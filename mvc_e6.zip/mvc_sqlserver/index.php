<?php
require_once 'Config/global.php';

$controller = $_GET['controller'] ?? CONTROLLER_DEFAULT;
$action     = $_GET['action']     ?? ACTION_DEFAULT;

switch ($controller) {
    case 'articles':
    default:
        require_once 'controller/articleController.php';
        $obj = new ArticlesController();
        break;
}
$obj->run($action);
?>
