<?php
define("DB_HOST",     "localhost\\SQLEXPRESS");
define("DB_USER",     "sa");
define("DB_PASS",     "TonMotDePasse");
define("DB_DATABASE", "mvc_articles");
?>
