<?php
define("CONTROLLER_DEFAULT", "articles");
define("ACTION_DEFAULT", "index");
require_once __DIR__ . '/../Config/database.php';
