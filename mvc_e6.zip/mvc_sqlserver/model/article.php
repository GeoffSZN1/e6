<?php
class Article {
    private $table = "Article";
    private $connexion;
    private $art_id, $art_nom, $art_prix, $art_poid, $art_image, $Id_Categorie;
    private $garantie, $stock, $type_article, $date_entree, $etat, $date_achat;

    public function __construct($connexion) { $this->connexion = $connexion; }

    public function getArt_id()      { return $this->art_id; }
    public function setArt_id($v)    { $this->art_id = $v; }
    public function setArt_nom($v)   { $this->art_nom = $v; }
    public function setArt_prix($v)  { $this->art_prix = $v; }
    public function setArt_poid($v)  { $this->art_poid = $v; }
    public function setArt_image($v) { $this->art_image = $v; }
    public function setIdCategorie($v){ $this->Id_Categorie = $v; }
    public function setGarantie($v)  { $this->garantie = $v; }
    public function setStock($v)     { $this->stock = $v; }
    public function setTypeArticle($v){ $this->type_article = $v; }
    public function setDateEntree($v){ $this->date_entree = $v; }
    public function setEtat($v)      { $this->etat = $v; }
    public function setDateAchat($v) { $this->date_achat = $v; }

    public function getAll() {
        $q = $this->connexion->prepare("
            SELECT a.art_id, a.art_nom, a.art_prix, a.art_poid, a.art_image,
                   c.nom_cat, d.stock, d.garantie,
                   CASE WHEN n.art_id IS NOT NULL THEN 'Neuf'
                        WHEN o.art_id IS NOT NULL THEN 'Occasion'
                        ELSE 'N/A' END AS type_article
            FROM Article a
            JOIN Categorie c ON c.Id_Categorie = a.Id_Categorie
            LEFT JOIN DetailArticle   d ON d.art_id = a.art_id
            LEFT JOIN ArticleNeuf     n ON n.art_id = a.art_id
            LEFT JOIN ArticleOccasion o ON o.art_id = a.art_id
            ORDER BY a.art_nom
        ");
        $q->execute();
        return $q->fetchAll();
    }

    public function getById($id) {
        $q = $this->connexion->prepare("
            SELECT a.art_id, a.art_nom, a.art_prix, a.art_poid, a.art_image,
                   a.Id_Categorie, c.nom_cat, d.stock, d.garantie,
                   n.date_entree, o.etat, o.date_achat,
                   CASE WHEN n.art_id IS NOT NULL THEN 'Neuf'
                        WHEN o.art_id IS NOT NULL THEN 'Occasion'
                        ELSE 'N/A' END AS type_article
            FROM Article a
            JOIN Categorie c ON c.Id_Categorie = a.Id_Categorie
            LEFT JOIN DetailArticle   d ON d.art_id = a.art_id
            LEFT JOIN ArticleNeuf     n ON n.art_id = a.art_id
            LEFT JOIN ArticleOccasion o ON o.art_id = a.art_id
            WHERE a.art_id = :id
        ");
        $q->execute(["id" => $id]);
        return $q->fetch();
    }

    public function getAllCategories() {
        $q = $this->connexion->prepare("SELECT Id_Categorie, nom_cat FROM Categorie ORDER BY nom_cat");
        $q->execute();
        return $q->fetchAll();
    }

    public function insert() {
        $q = $this->connexion->prepare("EXEC PS_AjouterArticle :nom, :prix, :poid, :image, :cat");
        $result = $q->execute([
            "nom" => $this->art_nom, "prix" => $this->art_prix,
            "poid" => $this->art_poid, "image" => $this->art_image,
            "cat" => $this->Id_Categorie,
        ]);
        $newId = $this->connexion->lastInsertId();
        if ($this->type_article === 'neuf') {
            $q2 = $this->connexion->prepare("INSERT INTO ArticleNeuf (art_id, date_entree) VALUES (:id, :date)");
            $q2->execute(["id" => $newId, "date" => $this->date_entree ?? date('Y-m-d')]);
        } elseif ($this->type_article === 'occasion') {
            $q2 = $this->connexion->prepare("INSERT INTO ArticleOccasion (art_id, etat, date_achat) VALUES (:id, :etat, :date)");
            $q2->execute(["id" => $newId, "etat" => $this->etat ?? 'Bon état', "date" => $this->date_achat]);
        }
        return $result;
    }

    public function update() {
        $q = $this->connexion->prepare("
            UPDATE Article SET art_nom=:nom, art_prix=:prix, art_poid=:poid, Id_Categorie=:cat
            WHERE art_id=:id
        ");
        $result = $q->execute(["id"=>$this->art_id,"nom"=>$this->art_nom,"prix"=>$this->art_prix,"poid"=>$this->art_poid,"cat"=>$this->Id_Categorie]);
        $q2 = $this->connexion->prepare("UPDATE DetailArticle SET garantie=:garantie, stock=:stock WHERE art_id=:id");
        $q2->execute(["id"=>$this->art_id,"garantie"=>$this->garantie,"stock"=>$this->stock]);
        return $result;
    }

    public function delete() {
        $q = $this->connexion->prepare("EXEC PS_SupprimerArticle :id");
        return $q->execute(["id" => $this->art_id]);
    }
}
?>
