<?php
class Connecteur {
    public function connexion() {
        try {
            $dsn = "sqlsrv:Server=" . DB_HOST . ";Database=" . DB_DATABASE;
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ]);
            return $pdo;
        } catch (PDOException $e) {
            die("Erreur connexion SQL Server : " . $e->getMessage());
        }
    }
}
?>
