<?php
class ArticlesController {
    private $connecteur, $connexion;

    public function __construct() {
        require_once __DIR__ . "/../core/connecteur.php";
        require_once __DIR__ . "/../model/article.php";
        $this->connecteur = new Connecteur();
        $this->connexion  = $this->connecteur->connexion();
    }

    public function run($action) {
        switch ($action) {
            case "detail":      $this->detail();      break;
            case "creer_form":  $this->creer_form();  break;
            case "creer":       $this->creer();       break;
            case "maj_form":    $this->maj_form();     break;
            case "maj":         $this->maj();          break;
            case "delete":      $this->delete();       break;
            default:            $this->index();        break;
        }
    }

    function index() {
        $A = new Article($this->connexion);
        $this->view("index", [
            "articles" => $A->getAll(),
            "titre"    => "Gestion des Articles"
        ]);
    }

    function detail() {
        $A = new Article($this->connexion);
        $this->view("detail", [
            "article" => $A->getById($_GET["id"]),
            "titre"   => "Détail Article"
        ]);
    }

    function creer_form() {
        $A = new Article($this->connexion);
        $this->view("creer_form", [
            "categories" => $A->getAllCategories(),
            "titre"      => "Ajouter un article"
        ]);
    }

    function creer() {
        $A = new Article($this->connexion);
        $A->setArt_nom($_POST["nom"]);
        $A->setArt_prix($_POST["prix"]);
        $A->setArt_poid($_POST["poid"]);
        $A->setIdCategorie($_POST["categorie"]);
        $A->setTypeArticle($_POST["type_article"]);
        $A->setGarantie($_POST["garantie"] ?? '1 an');
        $A->setStock($_POST["stock"] ?? 0);
        $A->setDateEntree($_POST["date_entree"] ?? date('Y-m-d'));
        $A->setEtat($_POST["etat"] ?? 'Bon état');
        $A->setDateAchat($_POST["date_achat"] ?? null);
        $A->setArt_image($this->uploadImage());
        if ($A->insert()) header('Location: index.php');
    }

    function maj_form() {
        $A = new Article($this->connexion);
        $this->view("maj", [
            "article"    => $A->getById($_GET["id"]),
            "categories" => $A->getAllCategories(),
            "titre"      => "Modifier l'article"
        ]);
    }

    function maj() {
        $A = new Article($this->connexion);
        $A->setArt_id($_POST["id"]);
        $A->setArt_nom($_POST["nom"]);
        $A->setArt_prix($_POST["prix"]);
        $A->setArt_poid($_POST["poid"]);
        $A->setIdCategorie($_POST["categorie"]);
        $A->setGarantie($_POST["garantie"]);
        $A->setStock($_POST["stock"]);
        if ($A->update()) header('Location: index.php');
    }

    function delete() {
        $A = new Article($this->connexion);
        $A->setArt_id($_POST["idDel"]);
        if ($A->delete()) header('Location: index.php');
    }

    function view($name, $data) {
        extract($data);
        require_once __DIR__ . "/../view/" . $name . "View.php";
    }

    function uploadImage() {
        $uploadDir = __DIR__ . '/img/';
        if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
            $allowed = ['image/jpeg','image/png','image/gif'];
            if (!in_array($_FILES['image']['type'], $allowed)) die("Type non autorisé");
            $fileName = time() . '_' . basename($_FILES['image']['name']);
            if (move_uploaded_file($_FILES['image']['tmp_name'], $uploadDir . $fileName))
                return $fileName;
        }
        return 'default.png';
    }
}
?>
