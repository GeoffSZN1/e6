<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Ajouter un article</title>
<style>
  body{font-family:Arial,sans-serif;margin:30px;background:#f5f5f5;}
  h1{color:#1F3864;}
  .card{background:#fff;padding:28px;max-width:560px;border-radius:8px;box-shadow:0 2px 8px rgba(0,0,0,.15);}
  label{display:block;margin-top:14px;font-weight:bold;color:#1F3864;}
  input[type=text],input[type=number],input[type=date],select{width:100%;padding:8px;box-sizing:border-box;border:1px solid #ccc;border-radius:4px;margin-top:4px;}
  .radio-group{display:flex;gap:20px;margin-top:8px;}
  .radio-group label{font-weight:normal;color:#333;display:flex;align-items:center;gap:6px;}
  .section-extra{margin-top:14px;padding:12px;background:#f0f4ff;border-radius:6px;display:none;}
  .btn-submit{margin-top:20px;padding:10px 24px;background:#27ae60;color:#fff;border:none;border-radius:6px;cursor:pointer;font-size:1em;font-weight:bold;}
  .btn-back{display:inline-block;margin-top:10px;color:#1F3864;text-decoration:none;}
</style>
</head>
<body>
<div class="card">
  <h1>Ajouter un article</h1>
  <form method="POST" action="index.php?controller=articles&action=creer" enctype="multipart/form-data">

    <label>Nom de l'article</label>
    <input type="text" name="nom" required placeholder="Ex: iPhone 17 Pro">

    <label>Prix (€)</label>
    <input type="number" name="prix" step="0.01" min="0" required placeholder="Ex: 1299.99">

    <label>Poids</label>
    <input type="text" name="poid" required placeholder="Ex: 200g">

    <label>Catégorie</label>
    <select name="categorie" required>
      <option value="">-- Sélectionner --</option>
      <?php foreach ($categories as $cat): ?>
        <option value="<?= $cat['Id_Categorie'] ?>"><?= htmlspecialchars($cat['nom_cat']) ?></option>
      <?php endforeach; ?>
    </select>

    <label>Type d'article</label>
    <div class="radio-group">
      <label><input type="radio" name="type_article" value="neuf" onclick="showSection('neuf')" required> Neuf</label>
      <label><input type="radio" name="type_article" value="occasion" onclick="showSection('occasion')"> Occasion</label>
    </div>

    <div class="section-extra" id="section-neuf">
      <label>Date d'entrée en stock</label>
      <input type="date" name="date_entree" value="<?= date('Y-m-d') ?>">
    </div>

    <div class="section-extra" id="section-occasion">
      <label>État</label>
      <select name="etat">
        <option value="Très bon état">Très bon état</option>
        <option value="Bon état">Bon état</option>
        <option value="État correct">État correct</option>
        <option value="À reconditionner">À reconditionner</option>
      </select>
      <label>Date d'achat original</label>
      <input type="date" name="date_achat">
    </div>

    <label>Stock initial</label>
    <input type="number" name="stock" min="0" value="0">

    <label>Garantie</label>
    <input type="text" name="garantie" value="1 an" placeholder="Ex: 2 ans">

    <label>Image</label>
    <input type="file" name="image" accept="image/jpeg,image/png,image/gif">

    <button class="btn-submit" type="submit">Enregistrer</button>
  </form>
  <br><a class="btn-back" href="index.php">← Retour à la liste</a>
</div>

<script>
function showSection(type) {
  document.getElementById('section-neuf').style.display     = type === 'neuf'     ? 'block' : 'none';
  document.getElementById('section-occasion').style.display = type === 'occasion' ? 'block' : 'none';
}
</script>
</body>
</html>
