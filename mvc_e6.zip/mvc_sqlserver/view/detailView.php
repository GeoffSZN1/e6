<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title><?= htmlspecialchars($titre) ?></title>
<style>
  body{font-family:Arial,sans-serif;margin:30px;background:#f5f5f5;}
  .card{background:#fff;padding:24px;max-width:500px;border-radius:8px;box-shadow:0 2px 8px rgba(0,0,0,.15);}
  h1{color:#1F3864;}
  img{max-height:180px;border-radius:6px;margin-bottom:16px;}
  table{width:100%;border-collapse:collapse;}
  td{padding:8px;border-bottom:1px solid #eee;}
  td:first-child{font-weight:bold;color:#1F3864;width:40%;}
  .badge{padding:4px 10px;border-radius:12px;font-weight:bold;}
  .badge-neuf{background:#d4edda;color:#155724;}
  .badge-occasion{background:#fff3cd;color:#856404;}
  a{color:#1F3864;}
</style>
</head>
<body>
<div class="card">
  <h1><?= htmlspecialchars($titre) ?></h1>
  <?php if ($article): ?>
  <img src="controller/img/<?= htmlspecialchars($article['art_image']) ?>" alt="">
  <table>
    <tr><td>Nom</td><td><?= htmlspecialchars($article['art_nom']) ?></td></tr>
    <tr><td>Prix</td><td><?= number_format($article['art_prix'],2,',',' ') ?> €</td></tr>
    <tr><td>Poids</td><td><?= htmlspecialchars($article['art_poid']) ?></td></tr>
    <tr><td>Catégorie</td><td><?= htmlspecialchars($article['nom_cat']) ?></td></tr>
    <tr><td>Type</td><td><span class="badge badge-<?= strtolower($article['type_article']) ?>"><?= $article['type_article'] ?></span></td></tr>
    <tr><td>Stock</td><td><?= $article['stock'] ?></td></tr>
    <tr><td>Garantie</td><td><?= htmlspecialchars($article['garantie'] ?? '-') ?></td></tr>
    <?php if ($article['type_article'] === 'Neuf'): ?>
    <tr><td>Date entrée</td><td><?= $article['date_entree'] ?></td></tr>
    <?php elseif ($article['type_article'] === 'Occasion'): ?>
    <tr><td>État</td><td><?= htmlspecialchars($article['etat']) ?></td></tr>
    <tr><td>Date achat</td><td><?= $article['date_achat'] ?></td></tr>
    <?php endif; ?>
  </table>
  <br><a href="index.php">← Retour à la liste</a>
  <?php else: ?>
  <p>Article introuvable.</p>
  <?php endif; ?>
</div>
</body>
</html>
