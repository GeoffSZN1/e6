<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Modifier l'article</title>
<style>
  body{font-family:Arial,sans-serif;margin:30px;background:#f5f5f5;}
  h1{color:#1F3864;}
  .card{background:#fff;padding:28px;max-width:560px;border-radius:8px;box-shadow:0 2px 8px rgba(0,0,0,.15);}
  label{display:block;margin-top:14px;font-weight:bold;color:#1F3864;}
  input[type=text],input[type=number],input[type=date],select{width:100%;padding:8px;box-sizing:border-box;border:1px solid #ccc;border-radius:4px;margin-top:4px;}
  .btn-submit{margin-top:20px;padding:10px 24px;background:#1F3864;color:#fff;border:none;border-radius:6px;cursor:pointer;font-size:1em;font-weight:bold;}
  .btn-back{display:inline-block;margin-top:10px;color:#1F3864;text-decoration:none;}
  img{max-height:80px;border-radius:4px;margin-top:8px;}
</style>
</head>
<body>
<div class="card">
  <h1>Modifier l'article</h1>
  <form method="POST" action="index.php?controller=articles&action=maj">
    <input type="hidden" name="id" value="<?= $article['art_id'] ?>">

    <label>Image actuelle</label>
    <img src="controller/img/<?= htmlspecialchars($article['art_image']) ?>" alt="">

    <label>Nom de l'article</label>
    <input type="text" name="nom" value="<?= htmlspecialchars($article['art_nom']) ?>" required>

    <label>Prix (€)</label>
    <input type="number" name="prix" step="0.01" value="<?= $article['art_prix'] ?>" required>

    <label>Poids</label>
    <input type="text" name="poid" value="<?= htmlspecialchars($article['art_poid']) ?>" required>

    <label>Catégorie</label>
    <select name="categorie" required>
      <?php foreach ($categories as $cat): ?>
        <option value="<?= $cat['Id_Categorie'] ?>" <?= $cat['Id_Categorie'] == $article['Id_Categorie'] ? 'selected' : '' ?>>
          <?= htmlspecialchars($cat['nom_cat']) ?>
        </option>
      <?php endforeach; ?>
    </select>

    <label>Stock</label>
    <input type="number" name="stock" min="0" value="<?= $article['stock'] ?? 0 ?>">

    <label>Garantie</label>
    <input type="text" name="garantie" value="<?= htmlspecialchars($article['garantie'] ?? '1 an') ?>">

    <button class="btn-submit" type="submit">Enregistrer les modifications</button>
  </form>
  <br><a class="btn-back" href="index.php">← Retour à la liste</a>
</div>
</body>
</html>
