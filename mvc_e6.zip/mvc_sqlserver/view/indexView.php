<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title><?= htmlspecialchars($titre) ?></title>
<style>
  body{font-family:Arial,sans-serif;margin:30px;background:#f5f5f5;}
  h1{color:#1F3864;}
  table{width:100%;border-collapse:collapse;background:#fff;box-shadow:0 2px 6px rgba(0,0,0,.1);}
  th{background:#1F3864;color:#fff;padding:10px;text-align:center;}
  td{padding:8px;border-bottom:1px solid #ddd;text-align:center;vertical-align:middle;}
  tr:hover{background:#f0f4ff;}
  .badge{padding:3px 10px;border-radius:12px;font-size:.8em;font-weight:bold;}
  .badge-neuf{background:#d4edda;color:#155724;}
  .badge-occasion{background:#fff3cd;color:#856404;}
  .badge-na{background:#e2e3e5;color:#383d41;}
  a.btn{padding:5px 10px;background:#1F3864;color:#fff;text-decoration:none;border-radius:4px;font-size:.85em;margin:2px;}
  a.btn-edit{background:#e67e22;}
  form{display:inline;}
  button.del{padding:5px 10px;background:#c0392b;color:#fff;border:none;border-radius:4px;cursor:pointer;font-size:.85em;}
  .add-btn{display:inline-block;margin-bottom:20px;padding:10px 22px;background:#27ae60;color:#fff;text-decoration:none;border-radius:6px;font-weight:bold;}
  img.thumb{height:40px;border-radius:4px;}
</style>
</head>
<body>
<h1><?= htmlspecialchars($titre) ?></h1>
<a class="add-btn" href="index.php?controller=articles&action=creer_form">+ Ajouter un article</a>
<table>
  <tr>
    <th>ID</th><th>Image</th><th>Nom</th><th>Prix</th><th>Poids</th>
    <th>Catégorie</th><th>Type</th><th>Stock</th><th>Garantie</th><th>Actions</th>
  </tr>
  <?php foreach ($articles as $a): ?>
  <tr>
    <td><?= $a['art_id'] ?></td>
    <td><img class="thumb" src="controller/img/<?= htmlspecialchars($a['art_image']) ?>" alt=""></td>
    <td><?= htmlspecialchars($a['art_nom']) ?></td>
    <td><?= number_format($a['art_prix'],2,',',' ') ?> €</td>
    <td><?= htmlspecialchars($a['art_poid']) ?></td>
    <td><?= htmlspecialchars($a['nom_cat']) ?></td>
    <td>
      <?php $type = $a['type_article']; $cls = strtolower($type) === 'n/a' ? 'na' : strtolower($type); ?>
      <span class="badge badge-<?= $cls ?>"><?= $type ?></span>
    </td>
    <td><?= $a['stock'] ?? 0 ?></td>
    <td><?= htmlspecialchars($a['garantie'] ?? '-') ?></td>
    <td>
      <a class="btn" href="index.php?controller=articles&action=detail&id=<?= $a['art_id'] ?>">Voir</a>
      <a class="btn btn-edit" href="index.php?controller=articles&action=maj_form&id=<?= $a['art_id'] ?>">Modifier</a>
      <form method="POST" action="index.php?controller=articles&action=delete" onsubmit="return confirm('Supprimer cet article ?')">
        <input type="hidden" name="idDel" value="<?= $a['art_id'] ?>">
        <button class="del">Supprimer</button>
      </form>
    </td>
  </tr>
  <?php endforeach; ?>
</table>
</body>
</html>
