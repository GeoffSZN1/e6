package com.ap3.app.api

import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

object RetrofitClient {

    /**
     * BASE_URL :
     *  - Émulateur Android Studio  → http://10.0.2.2/AP3/public/
     *  - Téléphone physique sur Wi-Fi → http://192.168.X.X/AP3/public/
     */
    private const val BASE_URL = "http://10.0.2.2/AP3/public/"

    var authToken: String? = null

    private val logging = HttpLoggingInterceptor().apply {
        level = HttpLoggingInterceptor.Level.BODY
    }

    private val client = OkHttpClient.Builder()
        .addInterceptor(logging)
        .addInterceptor { chain ->
            val req = chain.request().newBuilder()
            authToken?.let { req.addHeader("Authorization", "Bearer $it") }
            req.addHeader("Accept", "application/json")
            chain.proceed(req.build())
        }
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    val instance: ApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ApiService::class.java)
    }
}
