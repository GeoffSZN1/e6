package com.ap3.app

import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.ap3.app.api.RetrofitClient
import com.ap3.app.api.models.Categorie
import com.ap3.app.api.models.UpdateArtisteRequest
import com.ap3.app.databinding.ActivityEditArtisteBinding
import kotlinx.coroutines.launch

class EditArtisteActivity : AppCompatActivity() {

    private lateinit var binding: ActivityEditArtisteBinding
    private var categories: List<Categorie> = emptyList()
    private var artisteId: Int = -1

    companion object {
        const val EXTRA_ARTISTE_ID = "artiste_id"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEditArtisteBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Modifier l'artiste"

        artisteId = intent.getIntExtra(EXTRA_ARTISTE_ID, -1)
        if (artisteId == -1) { finish(); return }

        loadData()

        binding.btnSave.setOnClickListener { saveChanges() }
    }

    private fun loadData() {
        setLoading(true)
        lifecycleScope.launch {
            try {
                // Charge catégories + artiste en parallèle
                val catResp = RetrofitClient.instance.getCategories()
                val artResp = RetrofitClient.instance.getArtisteById(artisteId)

                if (catResp.isSuccessful) {
                    categories = catResp.body()?.data?.categories ?: emptyList()
                    val catNames = categories.map { it.nomCat }
                    val adapter = ArrayAdapter(
                        this@EditArtisteActivity,
                        android.R.layout.simple_spinner_item,
                        catNames
                    ).also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
                    binding.spinnerCategorie.adapter = adapter
                }

                if (artResp.isSuccessful) {
                    val artiste = artResp.body()?.data?.artiste
                    if (artiste != null) {
                        // Pré-remplissage du formulaire
                        binding.etNomArt.setText(artiste.nomArt)
                        binding.etDescription.setText(artiste.description ?: "")
                        binding.switchValide.isChecked = artiste.valide == 1

                        // Sélectionne la catégorie actuelle dans le spinner
                        val catIndex = categories.indexOfFirst { it.id == artiste.idCategorie }
                        if (catIndex >= 0) binding.spinnerCategorie.setSelection(catIndex)
                    }
                }
            } catch (e: Exception) {
                Toast.makeText(this@EditArtisteActivity, "Erreur chargement : ${e.message}", Toast.LENGTH_LONG).show()
                finish()
            } finally {
                setLoading(false)
            }
        }
    }

    private fun saveChanges() {
        val nom         = binding.etNomArt.text.toString().trim()
        val description = binding.etDescription.text.toString().trim()
        val valide      = if (binding.switchValide.isChecked) 1 else 0

        if (nom.isEmpty()) {
            binding.etNomArt.error = "Le nom est obligatoire"
            return
        }

        val selectedCat = if (categories.isNotEmpty()) {
            categories[binding.spinnerCategorie.selectedItemPosition]
        } else null

        val request = UpdateArtisteRequest(
            nom_art      = nom,
            description  = description.ifEmpty { null },
            idCategorie  = selectedCat?.id,
            valide       = valide
        )

        setSaveLoading(true)
        lifecycleScope.launch {
            try {
                val response = RetrofitClient.instance.updateArtiste(artisteId, request)

                if (response.isSuccessful) {
                    Toast.makeText(
                        this@EditArtisteActivity,
                        "Artiste modifié avec succès ✓",
                        Toast.LENGTH_SHORT
                    ).show()
                    finish() // Retour au détail
                } else {
                    Toast.makeText(
                        this@EditArtisteActivity,
                        "Erreur modification (${response.code()})",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this@EditArtisteActivity, "Erreur : ${e.message}", Toast.LENGTH_LONG).show()
            } finally {
                setSaveLoading(false)
            }
        }
    }

    private fun setLoading(on: Boolean) {
        binding.progressBar.visibility  = if (on) View.VISIBLE else View.GONE
        binding.formLayout.visibility   = if (on) View.GONE    else View.VISIBLE
    }

    private fun setSaveLoading(on: Boolean) {
        binding.btnSave.isEnabled      = !on
        binding.progressSave.visibility = if (on) View.VISIBLE else View.GONE
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) { onBackPressedDispatcher.onBackPressed(); return true }
        return super.onOptionsItemSelected(item)
    }
}
