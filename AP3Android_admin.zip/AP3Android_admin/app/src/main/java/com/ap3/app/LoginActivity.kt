package com.ap3.app

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.ap3.app.api.RetrofitClient
import com.ap3.app.api.models.LoginRequest
import com.ap3.app.databinding.ActivityLoginBinding
import kotlinx.coroutines.launch

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding
    private lateinit var session: SessionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        session = SessionManager(this)

        // Session existante → aller directement au MainActivity
        if (session.isLoggedIn()) {
            RetrofitClient.authToken = session.getToken()
            goToMain()
            return
        }

        // Switch Admin / Utilisateur
        binding.switchAdmin.setOnCheckedChangeListener { _, isAdmin ->
            if (isAdmin) {
                binding.tvLoginTitle.text    = "Connexion Administrateur"
                binding.tvLoginSubtitle.text = "Accès espace admin"
                binding.cardForm.setCardBackgroundColor(
                    resources.getColor(R.color.admin_card_bg, theme)
                )
                binding.btnLogin.backgroundTintList =
                    resources.getColorStateList(R.color.dark, theme)
            } else {
                binding.tvLoginTitle.text    = "Artistes"
                binding.tvLoginSubtitle.text = "Connectez-vous à votre compte"
                binding.cardForm.setCardBackgroundColor(
                    resources.getColor(R.color.white, theme)
                )
                binding.btnLogin.backgroundTintList =
                    resources.getColorStateList(R.color.dark, theme)
            }
            hideError()
        }

        binding.btnLogin.setOnClickListener {
            val login    = binding.etLogin.text.toString().trim()
            val password = binding.etPassword.text.toString().trim()

            if (login.isEmpty() || password.isEmpty()) {
                showError("Veuillez remplir tous les champs")
                return@setOnClickListener
            }

            doLogin(login, password, binding.switchAdmin.isChecked)
        }
    }

    private fun doLogin(login: String, password: String, isAdmin: Boolean) {
        setLoading(true)
        hideError()

        lifecycleScope.launch {
            try {
                val response = if (isAdmin) {
                    RetrofitClient.instance.adminLogin(
                        LoginRequest(login = login, mot_de_passe = password)
                    )
                } else {
                    RetrofitClient.instance.login(
                        LoginRequest(login = login, mot_de_passe = password)
                    )
                }

                if (response.isSuccessful) {
                    val data = response.body()?.data

                    if (data != null) {
                        val role = if (isAdmin) "admin" else (data.user.role ?: "user")

                        session.saveSession(
                            token  = data.access_token,
                            userId = data.user.id,
                            pseudo = data.user.pseudo,
                            email  = data.user.email,
                            role   = role
                        )
                        RetrofitClient.authToken = data.access_token

                        val msg = if (isAdmin) "Bienvenue Admin ${data.user.pseudo} !"
                                  else         "Bienvenue ${data.user.pseudo} !"
                        Toast.makeText(this@LoginActivity, msg, Toast.LENGTH_SHORT).show()
                        goToMain()
                    } else {
                        showError("Réponse inattendue du serveur")
                    }
                } else {
                    when (response.code()) {
                        401  -> showError(if (isAdmin) "Identifiants admin incorrects"
                                          else "Identifiants incorrects")
                        422  -> showError("Champs invalides")
                        else -> showError("Erreur serveur (${response.code()})")
                    }
                }
            } catch (e: java.net.ConnectException) {
                showError("Impossible de joindre le serveur.\nVérifiez que Laragon est démarré.")
            } catch (e: Exception) {
                showError("Erreur réseau : ${e.message}")
            } finally {
                setLoading(false)
            }
        }
    }

    private fun goToMain() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }

    private fun setLoading(on: Boolean) {
        binding.progressBar.visibility = if (on) View.VISIBLE else View.GONE
        binding.btnLogin.isEnabled     = !on
        binding.etLogin.isEnabled      = !on
        binding.etPassword.isEnabled   = !on
        binding.switchAdmin.isEnabled  = !on
    }

    private fun showError(msg: String) {
        binding.tvError.text       = msg
        binding.tvError.visibility = View.VISIBLE
    }

    private fun hideError() {
        binding.tvError.visibility = View.GONE
    }
}
