package com.ap3.app.api

import com.ap3.app.api.models.*
import retrofit2.Response
import retrofit2.http.*

interface ApiService {

    // ── AUTH UTILISATEUR ──────────────────────────────────────────────────────
    @POST("api/login")
    suspend fun login(@Body req: LoginRequest): Response<LoginResponse>

    @GET("api/me")
    suspend fun getMe(): Response<MeResponse>

    // ── AUTH ADMIN ────────────────────────────────────────────────────────────
    @POST("api/admin/login")
    suspend fun adminLogin(@Body req: LoginRequest): Response<LoginResponse>

    // ── ARTISTES publics ──────────────────────────────────────────────────────
    @GET("api/artistes")
    suspend fun getArtistes(@Query("categorie") categorieId: Int? = null): Response<ArtistesResponse>

    @GET("api/artistes/{id}")
    suspend fun getArtisteById(@Path("id") id: Int): Response<ArtisteDetailResponse>

    // ── CATÉGORIES ────────────────────────────────────────────────────────────
    @GET("api/categories")
    suspend fun getCategories(): Response<CategoriesResponse>

    // ── ADMIN : modifier ──────────────────────────────────────────────────────
    @PUT("api/admin/artistes/{id}")
    suspend fun updateArtiste(
        @Path("id") id: Int,
        @Body body: UpdateArtisteRequest
    ): Response<ArtisteDetailResponse>

    // ── ADMIN : supprimer ─────────────────────────────────────────────────────
    @DELETE("api/admin/artistes/{id}")
    suspend fun deleteArtiste(@Path("id") id: Int): Response<SimpleResponse>

    // ── ADMIN : valider / refuser ─────────────────────────────────────────────
    @PATCH("api/admin/artistes/{id}/validate")
    suspend fun validateArtiste(@Path("id") id: Int): Response<SimpleResponse>

    @PATCH("api/admin/artistes/{id}/refuse")
    suspend fun refuseArtiste(@Path("id") id: Int): Response<SimpleResponse>
}
