package com.ap3.app.api.models

import com.google.gson.annotations.SerializedName

// ── LOGIN ─────────────────────────────────────────────────────────────────────

data class LoginRequest(
    val login: String,
    val mot_de_passe: String
)

data class LoginResponse(
    val status: String,
    val message: String,
    val data: LoginData?
)

data class LoginData(
    val access_token: String,
    val refresh_token: String,
    val token_type: String,
    val expires_in: Int,
    val user: UserData
)

data class UserData(
    val id: Int,
    val pseudo: String,
    val email: String,
    val role: String? = null   // "admin" ou null pour les users normaux
)

// ── ME ────────────────────────────────────────────────────────────────────────

data class MeResponse(val status: String, val message: String, val data: MeData?)
data class MeData(val user: UserData)

// ── ARTISTE ───────────────────────────────────────────────────────────────────

data class Artiste(
    @SerializedName("Id_Artiste")   val id: Int,
    @SerializedName("nom_art")      val nomArt: String,
    @SerializedName("description")  val description: String?,
    @SerializedName("Id_Categorie") val idCategorie: Int,
    @SerializedName("nom_cat")      val nomCat: String?,
    @SerializedName("valide")       val valide: Int
)

data class ArtistesResponse(
    val status: String,
    val message: String,
    val data: ArtistesData?
)
data class ArtistesData(val count: Int, val artistes: List<Artiste>)

data class ArtisteDetailResponse(
    val status: String,
    val message: String,
    val data: ArtisteDetailData?
)
data class ArtisteDetailData(val artiste: Artiste)

// ── ADMIN : update ────────────────────────────────────────────────────────────

data class UpdateArtisteRequest(
    val nom_art: String?,
    val description: String?,
    @SerializedName("Id_Categorie") val idCategorie: Int?,
    val valide: Int?
)

// ── CATÉGORIE ─────────────────────────────────────────────────────────────────

data class Categorie(
    @SerializedName("Id_Categorie") val id: Int,
    @SerializedName("nom_cat")      val nomCat: String
)

data class CategoriesResponse(val status: String, val message: String, val data: CategoriesData?)
data class CategoriesData(val count: Int, val categories: List<Categorie>)

// ── RÉPONSE SIMPLE ────────────────────────────────────────────────────────────

data class SimpleResponse(val status: String, val message: String)
