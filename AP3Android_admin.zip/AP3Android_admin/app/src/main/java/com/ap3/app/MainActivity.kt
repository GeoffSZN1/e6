package com.ap3.app

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.ap3.app.api.RetrofitClient
import com.ap3.app.api.models.Artiste
import com.ap3.app.api.models.Categorie
import com.ap3.app.databinding.ActivityMainBinding
import com.google.android.material.chip.Chip
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var session: SessionManager
    private lateinit var adapter: ArtisteAdapter

    private var allArtistes: List<Artiste>  = emptyList()
    private var categories: List<Categorie> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        session = SessionManager(this)

        setSupportActionBar(binding.toolbar)

        // Badge admin dans le titre
        if (session.isAdmin()) {
            supportActionBar?.title    = "Artistes  🔑"
            supportActionBar?.subtitle = "Admin : ${session.getPseudo()}"
        } else {
            supportActionBar?.title    = "Artistes"
            supportActionBar?.subtitle = "Bonjour ${session.getPseudo()}"
        }

        adapter = ArtisteAdapter { artiste ->
            val intent = Intent(this, ArtisteDetailActivity::class.java)
            intent.putExtra(ArtisteDetailActivity.EXTRA_ARTISTE_ID, artiste.id)
            startActivity(intent)
        }
        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.adapter = adapter

        loadData()
    }

    override fun onResume() {
        super.onResume()
        // Recharge après un retour d'édition
        loadData()
    }

    private fun loadData() {
        setLoading(true)
        lifecycleScope.launch {
            try {
                val catResp = RetrofitClient.instance.getCategories()
                val artResp = RetrofitClient.instance.getArtistes()

                if (catResp.isSuccessful) {
                    categories = catResp.body()?.data?.categories ?: emptyList()
                    buildCategoryChips()
                }

                if (artResp.isSuccessful) {
                    allArtistes = artResp.body()?.data?.artistes ?: emptyList()
                    displayArtistes(allArtistes)
                } else {
                    showError("Erreur chargement artistes (${artResp.code()})")
                }
            } catch (e: Exception) {
                showError("Erreur réseau : ${e.message}")
            } finally {
                setLoading(false)
            }
        }
    }

    private fun buildCategoryChips() {
        binding.chipGroup.removeAllViews()

        val chipAll = Chip(this).apply {
            text        = "Toutes"
            isCheckable = true
            isChecked   = true
            setChipBackgroundColorResource(R.color.chip_selector)
            setTextColor(resources.getColorStateList(R.color.chip_text_selector, theme))
        }
        chipAll.setOnClickListener { displayArtistes(allArtistes) }
        binding.chipGroup.addView(chipAll)

        categories.forEach { cat ->
            val chip = Chip(this).apply {
                text        = cat.nomCat
                isCheckable = true
                tag         = cat.id
                setChipBackgroundColorResource(R.color.chip_selector)
                setTextColor(resources.getColorStateList(R.color.chip_text_selector, theme))
            }
            chip.setOnClickListener {
                displayArtistes(allArtistes.filter { it.idCategorie == cat.id })
            }
            binding.chipGroup.addView(chip)
        }
    }

    private fun displayArtistes(list: List<Artiste>) {
        adapter.submitList(list)
        binding.tvEmpty.visibility      = if (list.isEmpty()) View.VISIBLE else View.GONE
        binding.recyclerView.visibility = if (list.isEmpty()) View.GONE else View.VISIBLE
        binding.tvCount.text            = "${list.size} artiste(s)"
    }

    private fun setLoading(on: Boolean) {
        binding.progressBar.visibility  = if (on) View.VISIBLE else View.GONE
        binding.recyclerView.visibility = if (on) View.GONE    else View.VISIBLE
    }

    private fun showError(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_refresh -> { loadData(); true }
            R.id.action_logout  -> { logout(); true }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun logout() {
        session.clearSession()
        RetrofitClient.authToken = null
        startActivity(Intent(this, LoginActivity::class.java))
        finish()
    }
}
