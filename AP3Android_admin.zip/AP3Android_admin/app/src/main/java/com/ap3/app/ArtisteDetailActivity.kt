package com.ap3.app

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.ap3.app.api.RetrofitClient
import com.ap3.app.api.models.Artiste
import com.ap3.app.databinding.ActivityArtisteDetailBinding
import kotlinx.coroutines.launch

class ArtisteDetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityArtisteDetailBinding
    private lateinit var session: SessionManager
    private var currentArtiste: Artiste? = null

    companion object {
        const val EXTRA_ARTISTE_ID = "artiste_id"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityArtisteDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        session = SessionManager(this)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val artisteId = intent.getIntExtra(EXTRA_ARTISTE_ID, -1)
        if (artisteId == -1) { finish(); return }

        loadArtiste(artisteId)
    }

    private fun loadArtiste(id: Int) {
        setLoading(true)
        lifecycleScope.launch {
            try {
                val response = RetrofitClient.instance.getArtisteById(id)

                if (response.isSuccessful) {
                    val artiste = response.body()?.data?.artiste
                    if (artiste != null) {
                        currentArtiste = artiste
                        displayArtiste(artiste)
                    }
                } else {
                    Toast.makeText(this@ArtisteDetailActivity, "Artiste introuvable", Toast.LENGTH_SHORT).show()
                    finish()
                }
            } catch (e: Exception) {
                Toast.makeText(this@ArtisteDetailActivity, "Erreur réseau : ${e.message}", Toast.LENGTH_LONG).show()
                finish()
            } finally {
                setLoading(false)
            }
        }
    }

    private fun displayArtiste(artiste: Artiste) {
        supportActionBar?.title      = artiste.nomArt
        binding.tvNomArt.text        = artiste.nomArt
        binding.tvCategorie.text     = artiste.nomCat ?: "Sans catégorie"
        binding.tvDescription.text   = artiste.description?.takeIf { it.isNotBlank() }
                                        ?: "Aucune description disponible."
        binding.tvIdArtiste.text     = "ID : #${artiste.id}"

        // Badge statut
        if (artiste.valide == 1) {
            binding.tvStatut.text = "✓ Validé"
            binding.tvStatut.setBackgroundResource(R.drawable.bg_badge_valid)
        } else {
            binding.tvStatut.text = "⏳ En attente"
            binding.tvStatut.setBackgroundResource(R.drawable.bg_badge_pending)
        }

        // ── Section admin ──────────────────────────────────────────────────────
        if (session.isAdmin()) {
            binding.adminSection.visibility = View.VISIBLE

            // Bouton Modifier
            binding.btnEdit.setOnClickListener {
                val intent = Intent(this, EditArtisteActivity::class.java)
                intent.putExtra(EditArtisteActivity.EXTRA_ARTISTE_ID, artiste.id)
                startActivity(intent)
            }

            // Bouton Supprimer
            binding.btnDelete.setOnClickListener {
                confirmDelete(artiste)
            }

            // Bouton Valider / Refuser selon l'état actuel
            if (artiste.valide == 0) {
                binding.btnValidate.visibility = View.VISIBLE
                binding.btnRefuse.visibility   = View.GONE
                binding.btnValidate.setOnClickListener { toggleValidation(artiste.id, true) }
            } else {
                binding.btnValidate.visibility = View.GONE
                binding.btnRefuse.visibility   = View.VISIBLE
                binding.btnRefuse.setOnClickListener { toggleValidation(artiste.id, false) }
            }
        } else {
            binding.adminSection.visibility = View.GONE
        }
    }

    // ── Dialogue confirmation suppression ─────────────────────────────────────
    private fun confirmDelete(artiste: Artiste) {
        AlertDialog.Builder(this)
            .setTitle("Supprimer l'artiste")
            .setMessage("Voulez-vous vraiment supprimer « ${artiste.nomArt} » ?\nCette action est irréversible.")
            .setPositiveButton("Supprimer") { _, _ -> deleteArtiste(artiste.id) }
            .setNegativeButton("Annuler", null)
            .setIcon(android.R.drawable.ic_dialog_alert)
            .show()
    }

    private fun deleteArtiste(id: Int) {
        setLoading(true)
        lifecycleScope.launch {
            try {
                val response = RetrofitClient.instance.deleteArtiste(id)
                if (response.isSuccessful) {
                    Toast.makeText(this@ArtisteDetailActivity, "Artiste supprimé ✓", Toast.LENGTH_SHORT).show()
                    finish() // Retour à la liste
                } else {
                    Toast.makeText(this@ArtisteDetailActivity, "Erreur suppression (${response.code()})", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this@ArtisteDetailActivity, "Erreur : ${e.message}", Toast.LENGTH_LONG).show()
            } finally {
                setLoading(false)
            }
        }
    }

    // ── Valider / Refuser ─────────────────────────────────────────────────────
    private fun toggleValidation(id: Int, validate: Boolean) {
        lifecycleScope.launch {
            try {
                val response = if (validate) {
                    RetrofitClient.instance.validateArtiste(id)
                } else {
                    RetrofitClient.instance.refuseArtiste(id)
                }

                if (response.isSuccessful) {
                    val msg = if (validate) "Artiste validé ✓" else "Artiste refusé"
                    Toast.makeText(this@ArtisteDetailActivity, msg, Toast.LENGTH_SHORT).show()
                    loadArtiste(id) // Recharge pour mettre à jour le badge
                } else {
                    Toast.makeText(this@ArtisteDetailActivity, "Erreur (${response.code()})", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this@ArtisteDetailActivity, "Erreur : ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun setLoading(on: Boolean) {
        binding.progressBar.visibility   = if (on) View.VISIBLE else View.GONE
        binding.contentLayout.visibility = if (on) View.GONE    else View.VISIBLE
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) { onBackPressedDispatcher.onBackPressed(); return true }
        return super.onOptionsItemSelected(item)
    }

    override fun onResume() {
        super.onResume()
        // Recharge si on revient de l'écran d'édition
        currentArtiste?.let { loadArtiste(it.id) }
    }
}
