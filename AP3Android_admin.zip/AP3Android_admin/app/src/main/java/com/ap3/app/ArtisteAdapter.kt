package com.ap3.app

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.ap3.app.api.models.Artiste
import com.ap3.app.databinding.ItemArtisteBinding

class ArtisteAdapter(
    private val onClick: (Artiste) -> Unit
) : ListAdapter<Artiste, ArtisteAdapter.ViewHolder>(DIFF) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        ViewHolder(ItemArtisteBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(h: ViewHolder, pos: Int) = h.bind(getItem(pos))

    inner class ViewHolder(private val b: ItemArtisteBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(a: Artiste) {
            b.tvNomArt.text      = a.nomArt
            b.tvCategorie.text   = a.nomCat ?: "Sans catégorie"
            b.tvDescription.text = a.description?.takeIf { it.isNotBlank() } ?: "Aucune description"
            b.tvBadgeCategorie.text = a.nomCat?.uppercase() ?: "—"

            // Badge rouge si non validé
            if (a.valide == 0) {
                b.tvBadgePending.visibility = android.view.View.VISIBLE
            } else {
                b.tvBadgePending.visibility = android.view.View.GONE
            }

            b.root.setOnClickListener { onClick(a) }
        }
    }

    companion object {
        private val DIFF = object : DiffUtil.ItemCallback<Artiste>() {
            override fun areItemsTheSame(o: Artiste, n: Artiste) = o.id == n.id
            override fun areContentsTheSame(o: Artiste, n: Artiste) = o == n
        }
    }
}
