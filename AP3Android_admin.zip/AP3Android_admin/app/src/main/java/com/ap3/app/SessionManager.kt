package com.ap3.app

import android.content.Context
import android.content.SharedPreferences

class SessionManager(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    companion object {
        private const val PREFS_NAME  = "ap3_session"
        private const val KEY_TOKEN   = "access_token"
        private const val KEY_PSEUDO  = "pseudo"
        private const val KEY_EMAIL   = "email"
        private const val KEY_USER_ID = "user_id"
        private const val KEY_ROLE    = "role"
    }

    fun saveSession(
        token: String,
        userId: Int,
        pseudo: String,
        email: String,
        role: String = "user"
    ) {
        prefs.edit()
            .putString(KEY_TOKEN, token)
            .putInt(KEY_USER_ID, userId)
            .putString(KEY_PSEUDO, pseudo)
            .putString(KEY_EMAIL, email)
            .putString(KEY_ROLE, role)
            .apply()
    }

    fun getToken(): String?  = prefs.getString(KEY_TOKEN, null)
    fun getPseudo(): String? = prefs.getString(KEY_PSEUDO, null)
    fun getEmail(): String?  = prefs.getString(KEY_EMAIL, null)
    fun getUserId(): Int     = prefs.getInt(KEY_USER_ID, -1)
    fun getRole(): String    = prefs.getString(KEY_ROLE, "user") ?: "user"
    fun isLoggedIn(): Boolean = getToken() != null

    /** Retourne true si l'utilisateur connecté est admin */
    fun isAdmin(): Boolean = getRole() == "admin"

    fun clearSession() {
        prefs.edit().clear().apply()
    }
}
