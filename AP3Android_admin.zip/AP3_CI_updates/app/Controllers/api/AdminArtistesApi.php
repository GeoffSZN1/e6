<?php

namespace App\Controllers\api;

use App\Models\ArtisteModel;
use App\Models\CategorieModel;

class AdminArtistesApi extends BaseApiController
{
    /**
     * PUT /api/admin/artistes/{id}
     * Modifie un artiste existant
     */
    public function update(int $id)
    {
        $artisteModel = new ArtisteModel();
        $artiste = $artisteModel->find($id);

        if (! $artiste) {
            return $this->respond([
                'status'  => 'error',
                'message' => 'Artiste introuvable',
            ], 404);
        }

        $data = $this->requestData();
        $rules = [
            'nom_art'      => 'permit_empty|min_length[2]|max_length[100]',
            'description'  => 'permit_empty|max_length[255]',
            'Id_Categorie' => 'permit_empty|is_natural_no_zero',
            'valide'       => 'permit_empty|in_list[0,1]',
        ];

        if (! $this->validateData($data, $rules)) {
            return $this->failValidationErrors($this->validator->getErrors());
        }

        // Ne met à jour que les champs fournis
        $updateData = [];

        if (isset($data['nom_art']) && $data['nom_art'] !== '') {
            $updateData['nom_art'] = $data['nom_art'];
        }
        if (array_key_exists('description', $data)) {
            $updateData['description'] = $data['description'];
        }
        if (isset($data['Id_Categorie'])) {
            $categorieModel = new CategorieModel();
            if (! $categorieModel->find((int) $data['Id_Categorie'])) {
                return $this->respond([
                    'status'  => 'error',
                    'message' => 'Catégorie introuvable',
                ], 422);
            }
            $updateData['Id_Categorie'] = (int) $data['Id_Categorie'];
        }
        if (isset($data['valide'])) {
            $updateData['valide'] = (int) $data['valide'];
        }

        if (empty($updateData)) {
            return $this->respond([
                'status'  => 'error',
                'message' => 'Aucune donnée à mettre à jour',
            ], 422);
        }

        $artisteModel->update($id, $updateData);

        $artiste = $artisteModel
            ->select('Artiste.*, Categorie.nom_cat')
            ->join('Categorie', 'Categorie.Id_Categorie = Artiste.Id_Categorie', 'left')
            ->find($id);

        return $this->successResponse('Artiste modifié avec succès', [
            'artiste' => $artiste,
        ]);
    }

    /**
     * DELETE /api/admin/artistes/{id}
     * Supprime un artiste
     */
    public function destroy(int $id)
    {
        $artisteModel = new ArtisteModel();
        $artiste = $artisteModel->find($id);

        if (! $artiste) {
            return $this->respond([
                'status'  => 'error',
                'message' => 'Artiste introuvable',
            ], 404);
        }

        $artisteModel->delete($id);

        return $this->successResponse("Artiste #{$id} supprimé avec succès");
    }

    /**
     * PATCH /api/admin/artistes/{id}/validate
     * Valide un artiste (valide = 1)
     */
    public function validate(int $id)
    {
        $artisteModel = new ArtisteModel();

        if (! $artisteModel->find($id)) {
            return $this->respond(['status' => 'error', 'message' => 'Artiste introuvable'], 404);
        }

        $artisteModel->update($id, ['valide' => 1]);

        return $this->successResponse("Artiste #{$id} validé avec succès");
    }

    /**
     * PATCH /api/admin/artistes/{id}/refuse
     * Refuse un artiste (valide = 0)
     */
    public function refuse(int $id)
    {
        $artisteModel = new ArtisteModel();

        if (! $artisteModel->find($id)) {
            return $this->respond(['status' => 'error', 'message' => 'Artiste introuvable'], 404);
        }

        $artisteModel->update($id, ['valide' => 0]);

        return $this->successResponse("Artiste #{$id} refusé");
    }
}
