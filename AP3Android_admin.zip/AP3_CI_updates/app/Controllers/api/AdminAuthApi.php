<?php

namespace App\Controllers\api;

use App\Models\AdminModel;
use App\Services\JWTService;

class AdminAuthApi extends BaseApiController
{
    public function login()
    {
        $data = $this->requestData();
        $rules = [
            'login'        => 'required',
            'mot_de_passe' => 'required',
        ];

        if (! $this->validateData($data, $rules)) {
            return $this->failValidationErrors($this->validator->getErrors());
        }

        $adminModel = new AdminModel();
        $admin = $adminModel->findByPseudo($data['login']);

        if (! $admin || ! password_verify($data['mot_de_passe'], $admin['mot_de_passe'])) {
            return $this->respond([
                'status'  => 'error',
                'message' => 'Identifiants administrateur invalides',
            ], 401);
        }

        // Génère un token JWT avec le rôle admin
        $tokenPayload = [
            'Id_Client'    => $admin['Id_Admin'],
            'Pseudo'       => $admin['pseudo'],
            'e_mail'       => $admin['pseudo'], // pas d'email dans Admin
            'role'         => 'admin',
        ];

        $accessToken  = JWTService::generateToken($tokenPayload);
        $refreshToken = JWTService::generateRefreshToken($tokenPayload);

        return $this->successResponse('Connexion admin réussie', [
            'access_token'  => $accessToken,
            'refresh_token' => $refreshToken,
            'token_type'    => 'Bearer',
            'expires_in'    => JWTService::ACCESS_TTL,
            'user' => [
                'id'     => (int) $admin['Id_Admin'],
                'pseudo' => $admin['pseudo'],
                'email'  => '',
                'role'   => 'admin',
            ],
        ]);
    }
}
