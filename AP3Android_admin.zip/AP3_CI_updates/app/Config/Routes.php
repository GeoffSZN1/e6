<?php

use CodeIgniter\Router\RouteCollection;
use App\Controllers\api\ArtistesApi;
use App\Controllers\api\AuthApi;
use App\Controllers\api\CategoriesApi;
use App\Controllers\api\AdminAuthApi;
use App\Controllers\api\AdminArtistesApi;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Artistes::index');

// ── API publique ──────────────────────────────────────────────────────────────
$routes->group('api', static function ($routes) {
    // Auth utilisateurs
    $routes->post('register', '\\' . AuthApi::class . '::register');
    $routes->post('login',    '\\' . AuthApi::class . '::login');
    $routes->get('me',        '\\' . AuthApi::class . '::me', ['filter' => 'jwt']);

    // Artistes publics
    $routes->get('categories',        '\\' . CategoriesApi::class . '::index');
    $routes->get('artistes',          '\\' . ArtistesApi::class . '::index');
    $routes->get('artistes/(:num)',   '\\' . ArtistesApi::class . '::show/$1');
    $routes->post('artistes',         '\\' . ArtistesApi::class . '::store', ['filter' => 'jwt']);
});

// ── API admin ─────────────────────────────────────────────────────────────────
// Login admin (pas de filtre JWT)
$routes->post('api/admin/login', '\\' . AdminAuthApi::class . '::login');

// Routes admin protégées par JWT
$routes->group('api/admin', ['filter' => 'jwt'], static function ($routes) {
    $routes->put('artistes/(:num)',              '\\' . AdminArtistesApi::class . '::update/$1');
    $routes->delete('artistes/(:num)',           '\\' . AdminArtistesApi::class . '::destroy/$1');
    $routes->patch('artistes/(:num)/validate',   '\\' . AdminArtistesApi::class . '::validate/$1');
    $routes->patch('artistes/(:num)/refuse',     '\\' . AdminArtistesApi::class . '::refuse/$1');
});

// ── Routes web (inchangées) ───────────────────────────────────────────────────
$routes->get('login',     'AuthController::login');
$routes->post('login',    'AuthController::login');
$routes->get('register',  'AuthController::register');
$routes->post('register', 'AuthController::register');
$routes->get('logout',    'AuthController::logout');

$routes->get('admin/login',  'AuthController::loginAdmin');
$routes->post('admin/login', 'AuthController::loginAdmin');

$routes->group('admin', ['filter' => 'auth'], static function ($routes) {
    $routes->get('dashboard',                   'AdminController::index');
    $routes->get('artistes',                    'Admin\Artistes::index');
    $routes->get('artistes/create',             'Admin\Artistes::create');
    $routes->post('artistes/store',             'Admin\Artistes::store');
    $routes->get('artistes/edit/(:num)',        'Admin\Artistes::edit/$1');
    $routes->post('artistes/update/(:num)',     'Admin\Artistes::update/$1');
    $routes->get('artistes/delete/(:num)',      'Admin\Artistes::delete/$1');
    $routes->get('artistes/pending',            'Admin\Artistes::pending');
    $routes->get('artistes/validate/(:num)',    'Admin\Artistes::approve/$1');
    $routes->get('artistes/refuse/(:num)',      'Admin\Artistes::reject/$1');
});

$routes->get('artistes',                    'Artistes::index');
$routes->get('artistes/categorie/(:num)',   'Artistes::index/$1');
$routes->get('artistes/(:num)',             'Artistes::show/$1');
$routes->get('artistes/submit',             'Artistes::submit');
$routes->post('artistes/submit',            'Artistes::storeSubmission');
